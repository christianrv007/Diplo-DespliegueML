# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['todo_list', 'todo_list.todos']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'todo-list',
    'version': '0.1.0',
    'description': '',
    'long_description': '# todo list\nThis is a refactor project todo list\n\n# Setup\n* Create a virtual environment with:\n```\npython3 -m venv venv\n```\n\n* Activate the virtual environment\n\n```\nsource venv/bin/activate\n```\n\n# Install the other libraries\nRun the following command to install the other libraries.\n\n```\npip install -r requirements.txt\n```\n\n# Tests\n\n````\n$ pytest tests/integration/ -v\n````\n````\ntests/integration/test_integration.py::test_integration PASSED                                                                                [ 33%]\ntests/integration/test_integration.py::test_integration_parametrize[5-5-5/4-3/4-5] PASSED                                                     [ 66%]\ntests/integration/test_integration.py::test_integration_parametrize[8-7/5-15-3/8-137.475] PASSED                                              [100%]\n````',
    'author': 'christianrv007',
    'author_email': '40001043+christianrv007@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
